﻿namespace webApi.DTOs
{
    public class VendorNameDto
    {
        public string VendorName { get; set; }
    }
}

﻿namespace webApi.DTOs
{
    public class IdDto
    {
        public string Id { get; set; }
    }
}

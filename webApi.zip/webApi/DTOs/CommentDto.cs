﻿namespace webApi.DTOs
{
    public class CommentDto
    {
        public string Id { get; set; }
        public string ProductId { get; set; }
        public string Description { get; set; }
        public string UserName { get; set; }
    }
}
